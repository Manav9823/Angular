import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-loans',
  templateUrl: './delete-loans.component.html',
  styleUrls: ['./delete-loans.component.scss']
})
export class DeleteLoansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
