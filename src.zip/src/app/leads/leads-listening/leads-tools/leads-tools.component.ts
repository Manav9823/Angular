import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leads-tools',
  templateUrl: './leads-tools.component.html',
  styleUrls: ['./leads-tools.component.scss']
})
export class LeadsToolsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
