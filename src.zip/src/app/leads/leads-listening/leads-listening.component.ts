import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leads-listening',
  templateUrl: './leads-listening.component.html',
  styleUrls: ['./leads-listening.component.scss']
})
export class LeadsListeningComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
