import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-loans',
  templateUrl: './add-loans.component.html',
  styleUrls: ['./add-loans.component.scss']
})
export class AddLoansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
